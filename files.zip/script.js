// Simple calculator logic
const displayEl = document.getElementById('display');
const buttons = document.querySelectorAll('.btn');

let current = '';     // current entry as string
let previous = '';    // previous value as string
let operator = null;  // '+', '-', '*', '/'
let resetNext = false;

function updateDisplay() {
  displayEl.textContent = current || '0';
}

function inputNumber(n) {
  if (resetNext) {
    current = n === '.' ? '0.' : n;
    resetNext = false;
    updateDisplay();
    return;
  }
  if (n === '.' && current.includes('.')) return;
  if (n === '0' && current === '0') return;
  current = current === '0' && n !== '.' ? n : current + n;
  updateDisplay();
}

function chooseOperator(op) {
  if (current === '' && previous === '') return;
  if (previous !== '' && current !== '') {
    compute();
  } else if (current !== '') {
    previous = current;
  }
  operator = op;
  resetNext = true;
}

function compute() {
  if (!operator || previous === '') return;
  const a = parseFloat(previous);
  const b = parseFloat(current || previous); // support unary operations
  let result = 0;
  switch (operator) {
    case '+': result = a + b; break;
    case '-': result = a - b; break;
    case '*': result = a * b; break;
    case '/':
      if (b === 0) { alert("Cannot divide by zero"); clearAll(); return; }
      result = a / b; break;
    default: return;
  }
  // Limit precision
  result = Math.round((result + Number.EPSILON) * 1e12) / 1e12;
  current = String(result);
  previous = '';
  operator = null;
  resetNext = true;
  updateDisplay();
}

function clearAll() {
  current = '';
  previous = '';
  operator = null;
  resetNext = false;
  updateDisplay();
}

function backspace() {
  if (resetNext) { current = ''; resetNext = false; updateDisplay(); return; }
  current = current.slice(0, -1);
  updateDisplay();
}

// Handle button clicks
buttons.forEach(btn => {
  btn.addEventListener('click', () => {
    const val = btn.getAttribute('data-value');
    const action = btn.getAttribute('data-action');

    if (action === 'clear') { clearAll(); return; }
    if (action === 'back') { backspace(); return; }
    if (action === 'equals') { compute(); return; }
    if (val) {
      if ('0123456789.'.includes(val)) inputNumber(val);
      else if ('+-*/'.includes(val)) chooseOperator(val);
    }
  });
});

// Keyboard support
window.addEventListener('keydown', (e) => {
  if ((e.key >= '0' && e.key <= '9') || e.key === '.') {
    e.preventDefault();
    inputNumber(e.key);
    return;
  }
  if (e.key === 'Enter' || e.key === '=') {
    e.preventDefault();
    compute();
    return;
  }
  if (e.key === 'Backspace') {
    e.preventDefault();
    backspace();
    return;
  }
  if (e.key === 'Escape' || e.key.toLowerCase() === 'c') {
    e.preventDefault();
    clearAll();
    return;
  }
  if (['+', '-', '*', '/'].includes(e.key)) {
    e.preventDefault();
    chooseOperator(e.key);
    return;
  }
});
updateDisplay();